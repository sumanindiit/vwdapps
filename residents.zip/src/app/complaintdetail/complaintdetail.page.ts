import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaintdetail',
  templateUrl: './complaintdetail.page.html',
  styleUrls: ['./complaintdetail.page.scss'],
})
export class ComplaintdetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
