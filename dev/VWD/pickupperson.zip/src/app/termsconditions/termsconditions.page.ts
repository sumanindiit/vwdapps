import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-termsconditions',
  templateUrl: './termsconditions.page.html',
  styleUrls: ['./termsconditions.page.scss'],
})
export class TermsconditionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
