import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcomplaint',
  templateUrl: './addcomplaint.page.html',
  styleUrls: ['./addcomplaint.page.scss'],
})
export class AddcomplaintPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
